import sys
import os

# Add src to path
sys.path.append(os.path.join(os.path.dirname(__file__), 'src'))

from lexer import Lexer
from parser import Parser
from interpreter import Interpreter
from codegen import PythonGenerator

def run(code, interpreter=None):
    if interpreter is None:
        interpreter = Interpreter()
    
    try:
        lexer = Lexer(code)
        tokens = lexer.tokenize()
        parser = Parser(tokens)
        ast = parser.parse()
        return interpreter.interpret(ast)
    except Exception as e:
        print(f"خطأ: {e}")

def repl():
    print("لغة القلب 0.1 - مفسر تفاعلي")
    print("اكتب 'خروج' للمغادرة")
    interpreter = Interpreter()
    while True:
        try:
            text = input("القلب > ")
            if text.strip() == "خروج":
                break
            if not text.strip():
                continue
            run(text, interpreter)
        except EOFError:
            break
        except KeyboardInterrupt:
            print("\n")
            continue

def compile_to_python(code):
    try:
        lexer = Lexer(code)
        tokens = lexer.tokenize()
        parser = Parser(tokens)
        ast = parser.parse()
        generator = PythonGenerator()
        return generator.generate(ast)
    except Exception as e:
        print(f"خطأ في الترجمة: {e}")
        return None

def main():
    if len(sys.argv) > 1:
        if sys.argv[1] == "ترجم":
            if len(sys.argv) < 3:
                print("الرجاء تحديد ملف للترجمة")
                return
            filename = sys.argv[2]
            with open(filename, 'r', encoding='utf-8') as f:
                code = f.read()
            py_code = compile_to_python(code)
            if py_code:
                output_file = filename.replace('.qalb', '.py')
                with open(output_file, 'w', encoding='utf-8') as f:
                    f.write(py_code)
                print(f"تمت الترجمة بنجاح إلى: {output_file}")
        else:
            filename = sys.argv[1]
            with open(filename, 'r', encoding='utf-8') as f:
                code = f.read()
            run(code)
    else:
        repl()

if __name__ == "__main__":
    main()

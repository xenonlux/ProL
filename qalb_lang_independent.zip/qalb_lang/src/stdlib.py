import math

def get_stdlib():
    return {
        "جذر": math.sqrt,
        "جيب": math.sin,
        "جيب_تمام": math.cos,
        "ط": math.pi,
    }
